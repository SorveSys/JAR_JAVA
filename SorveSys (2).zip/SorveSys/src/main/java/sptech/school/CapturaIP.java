package sptech.school;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.rede.RedeInterface;

import java.util.List;

public class CapturaIP extends configuracao {
    
   
    private String TipoServidor;
    private Integer Empresa;
    
    public CapturaIP(String TipoServidor, Integer Empresa) {
        super();
        this.TipoServidor = TipoServidor;
        this.Empresa = Empresa;
    }
    
    public String getTipoServidor() {
        return TipoServidor;
    }
    
    public void setTipoServidor(String tipoServidor) {
        TipoServidor = tipoServidor;
    }
    
    public Integer getEmpresa() {
        return Empresa;
    }
    
    public void setEmpresa(Integer empresa) {
        Empresa = empresa;
    }
    
    public CapturaIP(Looca looca) {
        super(looca);
    }
    
    protected CapturaIP(String sql, Object... parametros) {
        super(sql, parametros);
    }
    
    @Override
    public void executarCaptura() {
        List<RedeInterface> interfaces = looca.getRede().getGrupoDeInterfaces().getInterfaces();
        
        RedeInterface placaAtiva = interfaces.stream()
                .filter(i -> i.getEnderecoIpv4() != null && !i.getEnderecoIpv4().isEmpty())
                .findFirst()
                .orElse(null);
        
        if (placaAtiva != null) {
            String ipv4 = placaAtiva.getEnderecoIpv4().get(0);
            System.out.println("IP Capturado: " + ipv4);
            
            String sql = "INSERT INTO servidor (tipo, ip, fk_empresa) VALUES (?, ?, ?)";
            
            new configuracao(sql, TipoServidor, ipv4, Empresa) {
                @Override
                public void executarCaptura() {
                
                }
            };
        }
    }
}
