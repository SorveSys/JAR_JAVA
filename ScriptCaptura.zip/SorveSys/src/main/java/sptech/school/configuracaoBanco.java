package sptech.school;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class configuracaoBanco {
    private static final String USER = "root";
    private static final String PASSWORD= "39836616";
    private static final String DATABASE = "sorvesys";
    
    private static final String URL = "jdbc:mysql://localhost:3306/" + DATABASE;
    
    public static Connection getConexao() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
